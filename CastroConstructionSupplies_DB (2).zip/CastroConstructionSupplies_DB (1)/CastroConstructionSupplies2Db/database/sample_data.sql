-- =====================================================================
-- OPTIONAL sample data so the screens are not empty. Import AFTER Castro_Database.sql.
-- 7 products with their batches (stock = the sum of each product's batches).
-- Customers are not included: register them in the app so their passwords are hashed.
-- =====================================================================
USE castro_construction;

INSERT INTO products (name, category_id, unit, purchase_price, selling_price, stock_quantity, reorder_level) VALUES
('Portland Cement 40kg',   (SELECT id FROM categories WHERE name='Construction Materials'), 'bag',   228.00, 265.00, 170, 30),
('Steel Rebar 10mm x 6m',  (SELECT id FROM categories WHERE name='Steel & Metal'),          'piece', 180.00, 215.00,  12, 25),
('Marine Plywood 1/2 inch',(SELECT id FROM categories WHERE name='Wood & Lumber'),          'sheet', 540.00, 640.00,   0, 15),
('Latex Paint White 4L',   (SELECT id FROM categories WHERE name='Paint & Finishing'),      'gallon',610.00, 735.00,   8, 10),
('PVC Pipe 1/2 inch',      (SELECT id FROM categories WHERE name='Plumbing'),               'piece',  85.00, 110.00,  60, 20),
('Claw Hammer 16oz',       (SELECT id FROM categories WHERE name='Tools'),                  'piece', 180.00, 250.00,  25, 10),
('LED Bulb 9W',            (SELECT id FROM categories WHERE name='Electrical'),             'piece',  60.00,  95.00,   4, 12);

INSERT INTO stock_batches (product_id, batch_no, quantity_received, quantity_remaining, purchase_price, received_date, notes) VALUES
((SELECT id FROM products WHERE name='Portland Cement 40kg'),    'OPENING', 120, 120, 220.00, '2026-09-20', 'Opening stock'),
((SELECT id FROM products WHERE name='Portland Cement 40kg'),    'B-0002',   50,  50, 228.00, '2026-10-01', 'Second delivery'),
((SELECT id FROM products WHERE name='Steel Rebar 10mm x 6m'),   'OPENING',  12,  12, 180.00, '2026-09-20', 'Opening stock'),
((SELECT id FROM products WHERE name='Marine Plywood 1/2 inch'), 'OPENING',  20,   0, 540.00, '2026-09-20', 'Opening stock (sold out)'),
((SELECT id FROM products WHERE name='Latex Paint White 4L'),    'OPENING',   8,   8, 610.00, '2026-09-20', 'Opening stock'),
((SELECT id FROM products WHERE name='PVC Pipe 1/2 inch'),       'OPENING',  60,  60,  85.00, '2026-09-20', 'Opening stock'),
((SELECT id FROM products WHERE name='Claw Hammer 16oz'),        'OPENING',  25,  25, 180.00, '2026-09-20', 'Opening stock'),
((SELECT id FROM products WHERE name='LED Bulb 9W'),             'OPENING',   4,   4,  60.00, '2026-09-20', 'Opening stock');
