-- =====================================================================
-- Castro Construction Supplies - database (MySQL / MariaDB, works with XAMPP)
-- 7 tables: categories, suppliers, customers, products, sales, sale_items, stock_batches
--
-- phpMyAdmin:  Import tab -> choose this file -> Go.
-- It creates a NEW database called  castro_construction  (the app connects to that name).
-- Do not import it into another database that already has tables with the same names.
-- =====================================================================
CREATE DATABASE IF NOT EXISTS castro_construction CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE castro_construction;

CREATE TABLE IF NOT EXISTS categories (
    id   INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(60) NOT NULL UNIQUE
);

INSERT IGNORE INTO categories(name) VALUES
    ('Construction Materials'), ('Concrete Products'), ('Steel & Metal'), ('Wood & Lumber'),
    ('Paint & Finishing'), ('Plumbing'), ('Electrical'), ('Tools');

CREATE TABLE IF NOT EXISTS suppliers (
    id      INT AUTO_INCREMENT PRIMARY KEY,
    name    VARCHAR(120) NOT NULL UNIQUE,
    contact VARCHAR(30),
    address VARCHAR(200)
);

CREATE TABLE IF NOT EXISTS customers (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    first_name    VARCHAR(60)  NOT NULL,
    last_name     VARCHAR(60)  NOT NULL,
    email         VARCHAR(120) NOT NULL,
    username      VARCHAR(60)  NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    contact       VARCHAR(30)  NOT NULL
);

CREATE TABLE IF NOT EXISTS products (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    name           VARCHAR(120) NOT NULL,
    category_id    INT NULL,
    supplier_id    INT NULL,
    unit           VARCHAR(20),
    purchase_price DECIMAL(12,2) NOT NULL DEFAULT 0,
    selling_price  DECIMAL(12,2) NOT NULL,
    stock_quantity INT NOT NULL DEFAULT 0,
    reorder_level  INT NOT NULL DEFAULT 10,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id)  ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS sales (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    sale_code     VARCHAR(20) UNIQUE,
    sale_date     VARCHAR(40) NOT NULL,
    customer_name VARCHAR(120),
    staff_name    VARCHAR(120),
    customer_id   INT NULL,
    status         VARCHAR(12) NOT NULL DEFAULT 'Completed',
    cancel_reason  VARCHAR(60) NOT NULL DEFAULT '',
    cancelled_by   VARCHAR(10) NOT NULL DEFAULT '',
    customer_notified TINYINT(1) NOT NULL DEFAULT 1,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS sale_items (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    sale_id      INT NOT NULL,
    product_id   INT NULL,
    product_name VARCHAR(120) NOT NULL,
    quantity     INT NOT NULL,
    unit_price   DECIMAL(12,2) NOT NULL,
    FOREIGN KEY (sale_id)    REFERENCES sales(id)    ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
);

-- Stock-In: every delivery of a product is one batch (sales use the oldest batch first)
CREATE TABLE IF NOT EXISTS stock_batches (
    id                 INT AUTO_INCREMENT PRIMARY KEY,
    product_id         INT NOT NULL,
    batch_no           VARCHAR(20) NOT NULL,
    quantity_received  INT NOT NULL,
    quantity_remaining INT NOT NULL,
    purchase_price     DECIMAL(12,2) NOT NULL,
    received_date      DATE NOT NULL,
    notes              VARCHAR(200) NOT NULL DEFAULT '',
    UNIQUE (product_id, batch_no),
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);
