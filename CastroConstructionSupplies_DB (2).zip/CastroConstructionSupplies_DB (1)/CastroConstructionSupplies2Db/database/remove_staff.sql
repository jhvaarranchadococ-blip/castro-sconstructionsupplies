-- OPTIONAL: for a database you already created with the older schema.
-- Removes the unused staff table and sales.staff_id. Customers, products, batches and sales are kept.
--
-- 1) BACK UP FIRST (run in a terminal, not in MySQL):
--      mysqldump -u root -p castro_construction > backup.sql
-- 2) Check the foreign key name:  SHOW CREATE TABLE sales;
--    (it is normally sales_ibfk_2 for staff_id; if yours is different, change the name below)
-- 3) Then run:  mysql -u root -p < database/remove_staff.sql
USE castro_construction;
ALTER TABLE sales DROP FOREIGN KEY sales_ibfk_2;
ALTER TABLE sales DROP COLUMN staff_id;
DROP TABLE IF EXISTS staff;
-- Old cancellations were saved as 'Staff'; the app now uses 'Admin'.
UPDATE sales SET cancelled_by = 'Admin' WHERE cancelled_by = 'Staff';
