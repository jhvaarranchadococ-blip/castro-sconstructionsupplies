package castroconstructionsupplies;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/** Staff accounts stored in MySQL (table: staff). The built-in admin login lives in Session/LoginFrame. */
public class StaffDAO {

    private static Staff read(ResultSet rs) throws SQLException {
        return new Staff(rs.getInt("id"), rs.getString("first_name"), rs.getString("last_name"),
                rs.getString("position"), rs.getString("contact"), rs.getString("username"), rs.getString("status"));
    }

    public static int count() {
        try (Connection con = DBConnection.get();
                PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) FROM staff");
                ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getInt(1) : 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }

    public static boolean usernameExists(String username, int excludeId) {
        try (Connection con = DBConnection.get();
                PreparedStatement ps = con.prepareStatement("SELECT 1 FROM staff WHERE LOWER(username)=LOWER(?) AND id<>?")) {
            ps.setString(1, username);
            ps.setInt(2, excludeId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean insert(String firstName, String lastName, String position, String contact,
            String username, String password) {
        if (usernameExists(username, 0)) {
            return false;
        }
        String sql = "INSERT INTO staff(first_name,last_name,position,contact,username,password_hash,status) VALUES(?,?,?,?,?,?,'Active')";
        try (Connection con = DBConnection.get(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, firstName);
            ps.setString(2, lastName);
            ps.setString(3, position);
            ps.setString(4, contact);
            ps.setString(5, username);
            ps.setString(6, PasswordUtil.hash(password));
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /** Only Active staff may log in. Returns null on failure. */
    public static Staff authenticate(String username, String password) {
        try (Connection con = DBConnection.get();
                PreparedStatement ps = con.prepareStatement(
                        "SELECT * FROM staff WHERE LOWER(username)=LOWER(?) AND status='Active'")) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next() && PasswordUtil.verify(password, rs.getString("password_hash"))) {
                    return read(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static List<Staff> search(String text) {
        String needle = text == null ? "" : text.trim().toLowerCase();
        List<Staff> result = new ArrayList<>();
        try (Connection con = DBConnection.get();
                PreparedStatement ps = con.prepareStatement("SELECT * FROM staff ORDER BY id");
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Staff s = read(rs);
                if (needle.isEmpty()
                        || s.getFullName().toLowerCase().contains(needle)
                        || s.getPosition().toLowerCase().contains(needle)
                        || s.getCode().toLowerCase().contains(needle)) {
                    result.add(s);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    public static boolean update(int id, String firstName, String lastName, String contact, String username) {
        String sql = "UPDATE staff SET first_name=?, last_name=?, contact=?, username=? WHERE id=?";
        try (Connection con = DBConnection.get(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, firstName);
            ps.setString(2, lastName);
            ps.setString(3, contact);
            ps.setString(4, username);
            ps.setInt(5, id);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean updatePositionAndStatus(int id, String position, String status) {
        try (Connection con = DBConnection.get();
                PreparedStatement ps = con.prepareStatement("UPDATE staff SET position=?, status=? WHERE id=?")) {
            ps.setString(1, position);
            ps.setString(2, status);
            ps.setInt(3, id);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean delete(int id) {
        try (Connection con = DBConnection.get();
                PreparedStatement ps = con.prepareStatement("DELETE FROM staff WHERE id=?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /** Sets a new password for a staff account (salted-hashed). */
    public static boolean resetPassword(int id, String newPassword) {
        try (Connection con = DBConnection.get();
                PreparedStatement ps = con.prepareStatement("UPDATE staff SET password_hash=? WHERE id=?")) {
            ps.setString(1, PasswordUtil.hash(newPassword));
            ps.setInt(2, id);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
