package castroconstructionsupplies;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/** Customer accounts stored in MySQL (table: customers). Passwords are salted-hashed. */
public class CustomerDAO {

    private static Customer read(ResultSet rs, boolean withHash) throws SQLException {
        Customer c = new Customer(rs.getInt("id"), rs.getString("first_name"), rs.getString("last_name"),
                rs.getString("email"), rs.getString("username"), rs.getString("contact"));
        if (withHash) {
            return withPassword(c, rs.getString("password_hash"));
        }
        return c;
    }

    private static Customer withPassword(Customer c, String hash) {
        Customer r = new Customer(c.getFirstName(), c.getLastName(), c.getEmail(), c.getUsername(), hash, c.getContact());
        r.setId(c.getId());
        return r;
    }

    public static boolean usernameExists(String username) {
        try (Connection con = DBConnection.get();
                PreparedStatement ps = con.prepareStatement("SELECT 1 FROM customers WHERE LOWER(username)=LOWER(?)")) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean insert(Customer c) {
        if (usernameExists(c.getUsername())) {
            return false;
        }
        String sql = "INSERT INTO customers(first_name,last_name,email,username,password_hash,contact) VALUES(?,?,?,?,?,?)";
        try (Connection con = DBConnection.get(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, c.getFirstName());
            ps.setString(2, c.getLastName());
            ps.setString(3, c.getEmail());
            ps.setString(4, c.getUsername());
            ps.setString(5, PasswordUtil.hash(c.getPassword()));
            ps.setString(6, c.getContact());
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static Customer authenticate(String username, String password) {
        try (Connection con = DBConnection.get();
                PreparedStatement ps = con.prepareStatement("SELECT * FROM customers WHERE LOWER(username)=LOWER(?)")) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next() && PasswordUtil.verify(password, rs.getString("password_hash"))) {
                    return read(rs, false);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static List<Customer> search(String text) {
        String needle = text == null ? "" : text.trim().toLowerCase();
        List<Customer> result = new ArrayList<>();
        try (Connection con = DBConnection.get();
                PreparedStatement ps = con.prepareStatement("SELECT * FROM customers ORDER BY id");
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Customer c = read(rs, false);
                if (needle.isEmpty()
                        || c.getFullName().toLowerCase().contains(needle)
                        || c.getEmail().toLowerCase().contains(needle)
                        || c.getUsername().toLowerCase().contains(needle)
                        || c.getCode().toLowerCase().contains(needle)) {
                    result.add(c);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    public static boolean update(int id, String firstName, String lastName, String contact, String email) {
        String sql = "UPDATE customers SET first_name=?, last_name=?, contact=?, email=? WHERE id=?";
        try (Connection con = DBConnection.get(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, firstName);
            ps.setString(2, lastName);
            ps.setString(3, contact);
            ps.setString(4, email);
            ps.setInt(5, id);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean delete(int id) {
        try (Connection con = DBConnection.get();
                PreparedStatement ps = con.prepareStatement("DELETE FROM customers WHERE id=?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static int count() {
        try (Connection con = DBConnection.get();
                PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) FROM customers");
                ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getInt(1) : 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }

    /** Forgot-password check: username, email AND contact number must all match. */
    public static Customer findForRecovery(String username, String email, String contact) {
        String sql = "SELECT * FROM customers WHERE LOWER(username)=LOWER(?) AND LOWER(email)=LOWER(?) AND contact=?";
        try (Connection con = DBConnection.get(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, username.trim());
            ps.setString(2, email.trim());
            ps.setString(3, contact.trim());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return read(rs, false);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /** Sets a new password (salted-hashed). Used by Forgot Password and by staff resets. */
    public static boolean resetPassword(int id, String newPassword) {
        try (Connection con = DBConnection.get();
                PreparedStatement ps = con.prepareStatement("UPDATE customers SET password_hash=? WHERE id=?")) {
            ps.setString(1, PasswordUtil.hash(newPassword));
            ps.setInt(2, id);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
