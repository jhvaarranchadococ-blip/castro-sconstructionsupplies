package castroconstructionsupplies;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/** Single place to change the MySQL connection settings. */
public class DBConnection {

    private static final String URL = "jdbc:mysql://localhost:3306/castro_construction"
            + "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    public static Connection get() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
