package castroconstructionsupplies;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/** Product catalog + stock levels stored in MySQL (table: products). */
public class ProductDAO {

    private static final String BASE = "SELECT p.id, p.name, COALESCE(c.name,'') AS category, p.unit, "
            + "p.selling_price AS price, p.purchase_price, p.stock_quantity, p.reorder_level "
            + "FROM products p LEFT JOIN categories c ON c.id = p.category_id ";

    /** Finds the category row by name, creating it first if it is new. Returns null for a blank name. */
    private static Integer categoryId(Connection con, String name) throws SQLException {
        if (name == null || name.trim().isEmpty()) {
            return null;
        }
        try (PreparedStatement ps = con.prepareStatement("INSERT IGNORE INTO categories(name) VALUES(?)")) {
            ps.setString(1, name.trim());
            ps.executeUpdate();
        }
        try (PreparedStatement ps = con.prepareStatement("SELECT id FROM categories WHERE name=?")) {
            ps.setString(1, name.trim());
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : null;
            }
        }
    }

    private static Product read(ResultSet rs) throws SQLException {
        return new Product(rs.getInt("id"), rs.getString("name"), rs.getString("category"),
                rs.getString("unit"), rs.getDouble("price"), rs.getDouble("purchase_price"),
                rs.getInt("stock_quantity"), rs.getInt("reorder_level"));
    }

    private static List<Product> query(String sql, String... params) {
        List<Product> result = new ArrayList<>();
        try (Connection con = DBConnection.get(); PreparedStatement ps = con.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                ps.setString(i + 1, params[i]);
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    result.add(read(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    public static boolean insert(Product p) {
        if (p.getReorderLevel() < 0) {
            p.setReorderLevel(10);
        }
        // the product is saved with 0 stock; opening stock is then recorded as its first batch
        String sql = "INSERT INTO products(name,category_id,unit,purchase_price,selling_price,stock_quantity,reorder_level) "
                + "VALUES(?,?,?,?,?,0,?)";
        int opening = p.getStockQuantity();
        try (Connection con = DBConnection.get()) {
            con.setAutoCommit(false);
            try {
                try (PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                    ps.setString(1, p.getName());
                    ps.setObject(2, categoryId(con, p.getCategory()), java.sql.Types.INTEGER);
                    ps.setString(3, p.getUnit());
                    ps.setDouble(4, p.getPurchasePrice());
                    ps.setDouble(5, p.getPrice());
                    ps.setInt(6, p.getReorderLevel());
                    if (ps.executeUpdate() != 1) {
                        con.rollback();
                        return false;
                    }
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        if (keys.next()) {
                            p.setId(keys.getInt(1));
                        }
                    }
                }
                if (opening > 0) {
                    String error = BatchDAO.addBatch(con, p.getId(), "OPENING", opening, p.getPurchasePrice(),
                            java.time.LocalDate.now().toString(), "Opening stock");
                    if (error != null) {
                        con.rollback();
                        return false;
                    }
                }
                con.commit();
                return true;
            } catch (SQLException e) {
                con.rollback();
                throw e;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /** Updates name, category, unit and both prices. Stock changes only through Stock-In and sales. */
    public static boolean update(Product p) {
        String sql = "UPDATE products SET name=?, category_id=?, unit=?, purchase_price=?, selling_price=? WHERE id=?";
        try (Connection con = DBConnection.get(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, p.getName());
            ps.setObject(2, categoryId(con, p.getCategory()), java.sql.Types.INTEGER);
            ps.setString(3, p.getUnit());
            ps.setDouble(4, p.getPurchasePrice());
            ps.setDouble(5, p.getPrice());
            ps.setInt(6, p.getId());
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean delete(int id) {
        try (Connection con = DBConnection.get();
                PreparedStatement ps = con.prepareStatement("DELETE FROM products WHERE id=?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean addStock(int id, int qty) {
        try (Connection con = DBConnection.get();
                PreparedStatement ps = con.prepareStatement(
                        "UPDATE products SET stock_quantity = stock_quantity + ? WHERE id=?")) {
            ps.setInt(1, qty);
            ps.setInt(2, id);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean setReorderLevel(int id, int level) {
        try (Connection con = DBConnection.get();
                PreparedStatement ps = con.prepareStatement("UPDATE products SET reorder_level=? WHERE id=?")) {
            ps.setInt(1, level);
            ps.setInt(2, id);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static Product findById(int id) {
        List<Product> list = query(BASE + "WHERE p.id=" + id);
        return list.isEmpty() ? null : list.get(0);
    }

    /** Products whose name or category contains the text (empty = all), A-Z. */
    public static List<Product> search(String text) {
        String like = "%" + (text == null ? "" : text.trim().toLowerCase()) + "%";
        return query(BASE + "WHERE LOWER(p.name) LIKE ? OR LOWER(c.name) LIKE ? ORDER BY p.name",
                like, like);
    }

    public static List<Product> findInStock() {
        return query(BASE + "WHERE p.stock_quantity > 0 ORDER BY p.name");
    }

    public static List<Product> findLowStock() {
        return query(BASE + "WHERE p.stock_quantity <= p.reorder_level ORDER BY p.stock_quantity");
    }

    public static int count() {
        try (Connection con = DBConnection.get();
                PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) FROM products");
                ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getInt(1) : 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }

    public static long totalStockUnits() {
        try (Connection con = DBConnection.get();
                PreparedStatement ps = con.prepareStatement("SELECT COALESCE(SUM(stock_quantity),0) FROM products");
                ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getLong(1) : 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }
}
