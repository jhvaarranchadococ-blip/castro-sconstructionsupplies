package castroconstructionsupplies;

import java.sql.Connection; 
import java.sql.DriverManager; 
import java.sql.SQLException;

public class DatabaseConnection {

    public static void main(String[] args) {

        // Update this URL if your database name is different (e.g., without apostrophes or spelling mistakes)
        String url = "jdbc:mysql://localhost:3306/catro'sconstructionsupplies"; 
        String user = "root"; 
        String password = "";

        try { 
            // Load MySQL Driver Class
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to Database
            Connection connection = DriverManager.getConnection(url, user, password);

            System.out.println("Database connected successfully!");

            connection.close();

        } catch (ClassNotFoundException e) { 
            System.out.println("MySQL driver not found!"); 
            e.printStackTrace();

        } catch (SQLException e) { 
            System.out.println("Database connection failed!"); 
            e.printStackTrace(); 
        } 
    } 
}