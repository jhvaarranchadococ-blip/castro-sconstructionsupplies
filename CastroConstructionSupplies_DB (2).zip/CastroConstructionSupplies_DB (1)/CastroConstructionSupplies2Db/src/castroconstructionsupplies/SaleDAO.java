package castroconstructionsupplies;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

/**
 * Sales history stored in MySQL (tables: sales, sale_items). A walk-in sale deducts stock
 * immediately (Completed). A customer's online order is saved as Pending and waits in a FIFO
 * queue until staff confirm it (stock deducted) or cancel it.
 */
public class SaleDAO {

    private static Sale read(Connection con, ResultSet rs) throws SQLException {
        int dbId = rs.getInt("id");
        ArrayList<SaleItem> items = new ArrayList<>();
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT product_id, product_name, quantity, unit_price FROM sale_items WHERE sale_id=?")) {
            ps.setInt(1, dbId);
            try (ResultSet ir = ps.executeQuery()) {
                while (ir.next()) {
                    items.add(new SaleItem(ir.getInt("product_id"), ir.getString("product_name"),
                            ir.getInt("quantity"), ir.getDouble("unit_price")));
                }
            }
        }
        Sale sale = new Sale(rs.getString("sale_code"), rs.getString("sale_date"),
                rs.getString("customer_name"), rs.getString("staff_name"), items);
        int cid = rs.getInt("customer_id");
        sale.setCustomerId(rs.wasNull() ? null : cid);
        sale.setStatus(rs.getString("status"));
        sale.setCancelReason(rs.getString("cancel_reason"));
        sale.setCancelledBy(rs.getString("cancelled_by"));
        sale.setCustomerNotified(rs.getBoolean("customer_notified"));
        return sale;
    }

    private static List<Sale> query(String sql, Object... params) {
        List<Sale> result = new ArrayList<>();
        try (Connection con = DBConnection.get(); PreparedStatement ps = con.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                ps.setObject(i + 1, params[i]);
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    result.add(read(con, rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    /** Returns null on success, otherwise a message to show the user. */
    public static String create(Sale sale, boolean completeImmediately) {
        try (Connection con = DBConnection.get()) {
            con.setAutoCommit(false);
            try {
                if (completeImmediately) {
                    String problem = checkStock(con, sale.getItems());
                    if (problem != null) {
                        con.rollback();
                        return problem;
                    }
                }
                int dbId;
                try (PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO sales(sale_date,customer_name,staff_name,customer_id,status) VALUES(?,?,?,?,?)",
                        Statement.RETURN_GENERATED_KEYS)) {
                    ps.setString(1, sale.getDate());
                    ps.setString(2, sale.getCustomerName());
                    ps.setString(3, sale.getStaffName());
                    ps.setObject(4, sale.getCustomerId(), Types.INTEGER);
                    ps.setString(5, completeImmediately ? "Completed" : "Pending");
                    ps.executeUpdate();
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        keys.next();
                        dbId = keys.getInt(1);
                    }
                }
                for (SaleItem item : sale.getItems()) {
                    try (PreparedStatement ps = con.prepareStatement(
                            "INSERT INTO sale_items(sale_id,product_id,product_name,quantity,unit_price) VALUES(?,?,?,?,?)")) {
                        ps.setInt(1, dbId);
                        ps.setInt(2, item.getProductId());
                        ps.setString(3, item.getProductName());
                        ps.setInt(4, item.getQuantity());
                        ps.setDouble(5, item.getUnitPrice());
                        ps.executeUpdate();
                    }
                }
                if (completeImmediately) {
                    deductStock(con, sale.getItems());
                }
                try (PreparedStatement ps = con.prepareStatement("UPDATE sales SET sale_code=? WHERE id=?")) {
                    ps.setString(1, code(dbId));
                    ps.setInt(2, dbId);
                    ps.executeUpdate();
                }
                con.commit();
                sale.setId(code(dbId));
                sale.setStatus(completeImmediately ? "Completed" : "Pending");
                return null;
            } catch (SQLException e) {
                con.rollback();
                throw e;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return "Database error: " + e.getMessage();
        }
    }

    private static String checkStock(Connection con, List<SaleItem> items) throws SQLException {
        for (SaleItem item : items) {
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT stock_quantity FROM products WHERE id=? FOR UPDATE")) {
                ps.setInt(1, item.getProductId());
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next() || rs.getInt(1) < item.getQuantity()) {
                        return "\"" + item.getProductName() + "\" no longer has enough stock.";
                    }
                }
            }
        }
        return null;
    }

    private static void deductStock(Connection con, List<SaleItem> items) throws SQLException {
        for (SaleItem item : items) {
            try (PreparedStatement ps = con.prepareStatement(
                    "UPDATE products SET stock_quantity = stock_quantity - ? WHERE id=?")) {
                ps.setInt(1, item.getQuantity());
                ps.setInt(2, item.getProductId());
                ps.executeUpdate();
            }
            BatchDAO.deductFifo(con, item.getProductId(), item.getQuantity());
        }
    }

    /** Confirms a Pending order: deducts stock and marks it Completed. Returns null on success. */
    public static String confirmOrder(String saleCode) {
        try (Connection con = DBConnection.get()) {
            con.setAutoCommit(false);
            try {
                int dbId = -1;
                try (PreparedStatement ps = con.prepareStatement(
                        "SELECT id FROM sales WHERE sale_code=? AND status='Pending' FOR UPDATE")) {
                    ps.setString(1, saleCode);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            dbId = rs.getInt(1);
                        }
                    }
                }
                if (dbId < 0) {
                    con.rollback();
                    return "This order is no longer pending.";
                }
                List<SaleItem> items = new ArrayList<>();
                try (PreparedStatement ps = con.prepareStatement(
                        "SELECT product_id, product_name, quantity, unit_price FROM sale_items WHERE sale_id=?")) {
                    ps.setInt(1, dbId);
                    try (ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) {
                            items.add(new SaleItem(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getDouble(4)));
                        }
                    }
                }
                String problem = checkStock(con, items);
                if (problem != null) {
                    con.rollback();
                    return problem;
                }
                deductStock(con, items);
                try (PreparedStatement ps = con.prepareStatement("UPDATE sales SET status='Completed' WHERE id=?")) {
                    ps.setInt(1, dbId);
                    ps.executeUpdate();
                }
                con.commit();
                return null;
            } catch (SQLException e) {
                con.rollback();
                throw e;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return "Database error: " + e.getMessage();
        }
    }

    /** Cancels a Pending order. No stock was ever deducted for it. */
    public static boolean cancelOrder(String saleCode) {
        return cancelOrder(saleCode, "");
    }

    /**
     * Staff cancel a Pending order and give the reason. If the order belongs to a registered
     * customer, that customer is notified (a pop-up the next time they open the app).
     */
    public static boolean cancelOrder(String saleCode, String reason) {
        try (Connection con = DBConnection.get();
                PreparedStatement ps = con.prepareStatement(
                        "UPDATE sales SET status='Cancelled', cancel_reason=?, cancelled_by='Admin', "
                        + "customer_notified=IF(customer_id IS NULL, 1, 0) WHERE sale_code=? AND status='Pending'")) {
            ps.setString(1, reason == null ? "" : reason);
            ps.setString(2, saleCode);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /** Orders staff cancelled that this customer has not been told about yet, oldest first. */
    public static List<Sale> findUnreadCancellations(Integer customerId) {
        if (customerId == null) {
            return new ArrayList<>();
        }
        return query("SELECT * FROM sales WHERE customer_id=? AND status='Cancelled' AND cancelled_by='Admin' "
                + "AND customer_notified=0 ORDER BY id ASC", customerId);
    }

    /** Marks every staff cancellation of this customer as seen. */
    public static void markNotified(Integer customerId) {
        if (customerId == null) {
            return;
        }
        try (Connection con = DBConnection.get();
                PreparedStatement ps = con.prepareStatement(
                        "UPDATE sales SET customer_notified=1 WHERE customer_id=? AND status='Cancelled'")) {
            ps.setInt(1, customerId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * A customer cancels THEIR OWN order while it is still Pending. Returns null on success,
     * otherwise a message to show. The reason is saved with the order.
     */
    public static String cancelOwnOrder(String saleCode, Integer customerId, String reason) {
        if (customerId == null) {
            return "You can only cancel your own orders.";
        }
        try (Connection con = DBConnection.get()) {
            String status = null;
            Integer owner = null;
            try (PreparedStatement ps = con.prepareStatement("SELECT status, customer_id FROM sales WHERE sale_code=?")) {
                ps.setString(1, saleCode);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        status = rs.getString("status");
                        int c = rs.getInt("customer_id");
                        owner = rs.wasNull() ? null : c;
                    }
                }
            }
            if (status == null || !customerId.equals(owner)) {
                return "You can only cancel your own orders.";
            }
            if (!"Pending".equals(status)) {
                return "Only orders that are still waiting to be confirmed can be cancelled.";
            }
            try (PreparedStatement ps = con.prepareStatement(
                    "UPDATE sales SET status='Cancelled', cancel_reason=?, cancelled_by='Customer', customer_notified=1 "
                    + "WHERE sale_code=? AND customer_id=? AND status='Pending'")) {
                ps.setString(1, reason == null ? "" : reason);
                ps.setString(2, saleCode);
                ps.setInt(3, customerId);
                return ps.executeUpdate() == 1 ? null : "Only orders that are still waiting to be confirmed can be cancelled.";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return "Database error: " + e.getMessage();
        }
    }

    /** Pending orders, oldest first. */
    public static List<Sale> findQueue() {
        return query("SELECT * FROM sales WHERE status='Pending' ORDER BY id ASC");
    }

    public static int queueCount() {
        try (Connection con = DBConnection.get();
                PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) FROM sales WHERE status='Pending'");
                ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getInt(1) : 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }

    /** All sales, newest first. Pass a customer id to see only that customer's orders. */
    public static List<Sale> findAll(Integer customerId) {
        if (customerId == null) {
            return query("SELECT * FROM sales ORDER BY id DESC");
        }
        return query("SELECT * FROM sales WHERE customer_id=? ORDER BY id DESC", customerId);
    }

    public static List<Sale> findRecent(int max) {
        return query("SELECT * FROM sales ORDER BY id DESC LIMIT ?", max);
    }

    /** Sum of Completed sales only. */
    public static double totalAmount() {
        String sql = "SELECT COALESCE(SUM(si.quantity*si.unit_price),0) FROM sales s "
                + "JOIN sale_items si ON si.sale_id=s.id WHERE s.status='Completed'";
        try (Connection con = DBConnection.get();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getDouble(1) : 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }

    public static String code(int id) {
        return String.format("TXN-%05d", id);
    }
}
