package castroconstructionsupplies;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Stock batches (deliveries) stored in MySQL (table: stock_batches).
 * Stock-In = add a batch: the product's stock goes up by the batch quantity and its purchase
 * price becomes the latest batch cost. Sales use the OLDEST batch first (FIFO).
 */
public class BatchDAO {

    /** Suggested batch number for the next delivery of this product, e.g. B-0003. */
    public static String suggestBatchNo(int productId) {
        try (Connection con = DBConnection.get();
                PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) FROM stock_batches WHERE product_id=?")) {
            ps.setInt(1, productId);
            try (ResultSet rs = ps.executeQuery()) {
                return String.format("B-%04d", (rs.next() ? rs.getInt(1) : 0) + 1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return "B-0001";
        }
    }

    public static boolean batchNoExists(int productId, String batchNo) {
        try (Connection con = DBConnection.get()) {
            return batchNoExists(con, productId, batchNo);
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private static boolean batchNoExists(Connection con, int productId, String batchNo) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT 1 FROM stock_batches WHERE product_id=? AND LOWER(batch_no)=LOWER(?)")) {
            ps.setInt(1, productId);
            ps.setString(2, batchNo.trim());
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    /** Records a delivery and adds it to the product's stock. Returns null on success, else a message. */
    public static String addBatch(int productId, String batchNo, int qty, double purchasePrice,
            String receivedDate, String notes) {
        try (Connection con = DBConnection.get()) {
            con.setAutoCommit(false);
            try {
                String error = addBatch(con, productId, batchNo, qty, purchasePrice, receivedDate, notes);
                if (error != null) {
                    con.rollback();
                    return error;
                }
                con.commit();
                return null;
            } catch (SQLException e) {
                con.rollback();
                throw e;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return "Database error: " + e.getMessage();
        }
    }

    /** Same, inside a transaction the caller controls (used when a product is created with opening stock). */
    static String addBatch(Connection con, int productId, String batchNo, int qty, double purchasePrice,
            String receivedDate, String notes) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement("SELECT id FROM products WHERE id=? FOR UPDATE")) {
            ps.setInt(1, productId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return "That product no longer exists.";
                }
            }
        }
        if (batchNoExists(con, productId, batchNo)) {
            return "Batch number \"" + batchNo.trim() + "\" is already used for this product.";
        }
        try (PreparedStatement ps = con.prepareStatement(
                "INSERT INTO stock_batches(product_id,batch_no,quantity_received,quantity_remaining,"
                + "purchase_price,received_date,notes) VALUES(?,?,?,?,?,?,?)")) {
            ps.setInt(1, productId);
            ps.setString(2, batchNo.trim());
            ps.setInt(3, qty);
            ps.setInt(4, qty);
            ps.setDouble(5, purchasePrice);
            ps.setDate(6, Date.valueOf(receivedDate));
            ps.setString(7, notes == null ? "" : notes);
            ps.executeUpdate();
        }
        try (PreparedStatement ps = con.prepareStatement(
                "UPDATE products SET stock_quantity = stock_quantity + ?, purchase_price = ? WHERE id=?")) {
            ps.setInt(1, qty);
            ps.setDouble(2, purchasePrice);
            ps.setInt(3, productId);
            ps.executeUpdate();
        }
        return null;
    }

    /** Batches of one product, newest first. */
    public static List<StockBatch> findByProduct(int productId) {
        List<StockBatch> result = new ArrayList<>();
        try (Connection con = DBConnection.get();
                PreparedStatement ps = con.prepareStatement(
                        "SELECT * FROM stock_batches WHERE product_id=? ORDER BY id DESC")) {
            ps.setInt(1, productId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    result.add(new StockBatch(rs.getInt("id"), rs.getInt("product_id"), rs.getString("batch_no"),
                            rs.getInt("quantity_received"), rs.getInt("quantity_remaining"),
                            rs.getDouble("purchase_price"), rs.getDate("received_date").toString(),
                            rs.getString("notes")));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    /** Takes units out of the oldest batches first (inside the sale's transaction). */
    static void deductFifo(Connection con, int productId, int qty) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT id, quantity_remaining FROM stock_batches WHERE product_id=? AND quantity_remaining>0 "
                + "ORDER BY received_date, id FOR UPDATE")) {
            ps.setInt(1, productId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next() && qty > 0) {
                    int take = Math.min(qty, rs.getInt("quantity_remaining"));
                    try (PreparedStatement up = con.prepareStatement(
                            "UPDATE stock_batches SET quantity_remaining = quantity_remaining - ? WHERE id=?")) {
                        up.setInt(1, take);
                        up.setInt(2, rs.getInt("id"));
                        up.executeUpdate();
                    }
                    qty -= take;
                }
            }
        }
    }
}
