CASTRO CONSTRUCTION SUPPLIES - DATABASE (MySQL) VERSION
=======================================================
1. Install MySQL and run:   mysql -u root -p < database/schema.sql
   (Already ran an older schema? The tables changed. Run  DROP DATABASE castro_construction;
    first, then schema.sql. Old test data is lost.)
2. Edit src/castroconstructionsupplies/DBConnection.java (URL / USER / PASSWORD).
3. NetBeans: the project points to the bundled "MySQL JDBC Driver" library. If it shows as broken,
   right-click Libraries > Add JAR and pick mysql-connector-j-x.y.z.jar (from dev.mysql.com).
4. Run. Built-in admin login: admin / admin123 (not stored in the database; login screen: Admin or Customer).

Tables (7): categories, suppliers, customers, products, sales, sale_items, stock_batches.
There is no staff table any more. Already have the older database? Back it up, then run database/remove_staff.sql
(optional; see the notes inside it).
Products have purchase_price and selling_price. Stock-In adds a row to stock_batches and raises stock;
sales take stock from the oldest batch first. Cancelled orders keep a cancel_reason.
The admin cancels pending orders with a reason; the customer sees a pop-up with it the next time they log in
(sales.cancelled_by, sales.customer_notified). Sales History shows the reason.
Staff is removed from the menu, login and dashboard (Staff files kept but unused). No payment feature.
Customer passwords are PBKDF2-hashed in customers.password_hash.
